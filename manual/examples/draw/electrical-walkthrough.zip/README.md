# 储能一次接线图逐步练习资料

配合手册第13.3章使用。先导出CLI自带Skills，按章节提示词让AI操作。

- 01-generate.json：第一轮三支路自动排布方案。
- 02-emphasize.json：第二轮修改标题及A回路文字颜色。
- 03-move.json：第三轮A回路整体左移80。
- 同名ctproj：每轮参考结果，可直接在澄图编辑器中打开。
- storage-electrical.ctproj：原始空白工程。
- storage-electrical-data.json：变量与字段路径。
- storage-device-catalog.json：设备测点目录。
- storage-electrical-config.json和storage-electrical-response.json：本机模拟配置和响应。
- 04-response.json：只把A功率改为-160的对照响应。

需要复现参考结果时，在PowerShell中调用：

```powershell
.\Replay.ps1 -Cli '这里填写chengtu-cli.exe完整路径' -Destination '.\我的复现结果'
```

输出目录必须尚未存在。脚本只在该新目录生成工程和预览，不覆盖输入文件，不连接真实设备。
生成后按脚本输出启动本机预览。若环境不允许运行脚本，让AI阅读脚本并执行等价CLI命令即可。

资料中的设备和连接仅作制图练习。未绑定项、参考设备和待确认连接按原样保留。
