param(
  [Parameter(Mandatory=$true)][string]$Cli,
  [string]$Destination = (Join-Path $PSScriptRoot '复现输出')
)
$ErrorActionPreference = 'Stop'
$Cli = (Resolve-Path -LiteralPath $Cli).Path
if (Test-Path -LiteralPath $Destination) { throw '输出目录已存在，请选择一个新目录。' }
$taskOutput = New-Item -ItemType Directory -Path $Destination
$taskRoot = $taskOutput.FullName
function Invoke-Chengtu {
  param([string[]]$CliArgs)
  $taskRaw = & $Cli @CliArgs
  if ($LASTEXITCODE -ne 0) { throw ($taskRaw -join "`n") }
  return (($taskRaw -join "`n") | ConvertFrom-Json)
}
$taskInput = Join-Path $PSScriptRoot 'storage-electrical.ctproj'
$taskInputHash = (Get-FileHash -LiteralPath $taskInput -Algorithm SHA256).Hash
foreach ($taskRound in @('01-generate','02-emphasize','03-move')) {
  $taskPlan = Join-Path $PSScriptRoot ($taskRound + '.json')
  $taskWeb = Join-Path $taskRoot ($taskRound + '-web')
  $taskExtra = @()
  if ($taskRound -eq '01-generate') {
    $taskExtra = @('--data-contract',(Join-Path $PSScriptRoot 'storage-electrical-data.json'),
      '--device-catalog',(Join-Path $PSScriptRoot 'storage-device-catalog.json'))
  }
  $taskPreview = Invoke-Chengtu -CliArgs (@('preview',$taskInput,'--plan',$taskPlan) + $taskExtra + @('--web-preview',$taskWeb))
  if ($taskPreview.status -eq 'needs_input' -or $taskPreview.questions.Count -gt 0) {
    throw '预览需要补充信息，已停止，未执行本轮保存。'
  }
  $taskNext = Join-Path $taskRoot ($taskRound + '.ctproj')
  $null = Invoke-Chengtu -CliArgs (@('apply',$taskInput,'--plan',$taskPlan) + $taskExtra + @('--expect-base',$taskPreview.baseSha256,'--out',$taskNext))
  $taskReport = Invoke-Chengtu -CliArgs @('inspect',$taskNext)
  if ($taskReport.electrical.changedReadings.Count -ne 0 -or $taskReport.electrical.changedConnections.Count -ne 0) {
    throw '保存后映射或连接发生变化，请检查输出工程。'
  }
  foreach ($taskFile in @('storage-electrical-config.json','storage-electrical-response.json')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot $taskFile) -Destination $taskWeb
  }
  [IO.File]::WriteAllText((Join-Path $taskRoot ($taskRound + '-inspect.json')),
    ($taskReport | ConvertTo-Json -Depth 100), (New-Object Text.UTF8Encoding($false)))
  Write-Output ('已完成 ' + $taskRound + '，工程：' + $taskNext)
  $taskInput = $taskNext
}
if ((Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'storage-electrical.ctproj') -Algorithm SHA256).Hash -ne $taskInputHash) {
  throw '空白工程已变化，请核对。'
}
Write-Output ('预览命令：& "' + $Cli + '" serve "' + (Join-Path $taskRoot '03-move-web') + '" --port 0')
Write-Output '在命令返回的地址后添加 ?config=./storage-electrical-config.json。'
